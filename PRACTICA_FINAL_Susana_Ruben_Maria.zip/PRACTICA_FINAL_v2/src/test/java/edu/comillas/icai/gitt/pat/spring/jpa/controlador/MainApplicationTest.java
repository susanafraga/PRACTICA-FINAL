package edu.comillas.icai.gitt.pat.spring.jpa.controlador;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.core.AutoConfigureCache;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.json.JsonContent;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
class MainApplicationTests {
    TestRestTemplate restTemplate = new TestRestTemplate();


    //TEST DE LOS ENDPOINTS DE UNIVERSIDAD
    @Test()
    @DisplayName("GET /api/{ciudadId}/universidad/ retorna la lista de universidades")
    //Se prueba con las universidades que son de Madrid (ciudadId = 1)
    public void universidadesPorCiudadTest() {
        // Given ...
        String endpoint = "/api/1/universidad/";
        // When ...
        ResponseEntity<List> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, List.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test()
    @DisplayName("GET /api/{ciudadId}/universidad/")
    //Se prueba con una variable que no es de tipo Long ni pertenece a la lista de ciudades
    public void unisPorCiudadErrorTest() {
        // Given ...
        String endpoint = "/api/hola/universidad/";
        // When ...
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, String.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    @Test()
    @DisplayName("GET /api/universidad/{universidadId}/carrera retorna la lista de carreras de esa universidad")
    //Se prueba con la universidad 1 que es Comillas
    public void carrerasPorUniversidadTest() {
        // Given ...
        String endpoint = "/api/universidad/1/carrera";
        // When ...
        ResponseEntity<Iterable> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, Iterable.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test()
    @DisplayName("GET /api/universidad/{universidadId}/carrera")
    //Se prueba con un valor que no se encuentra de universidadId
    public void carrerasPorUniError() {
        // Given ...
        String endpoint = "/api/universidad/hola/carrera";
        // When ...
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, String.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

    }

    //TESTS DE LOS ENDPOINTS DE COLEGIOS
    @Test()
    @DisplayName("GET /api/{tipo}/colegio/ retorna la lista de colegios del tipo indicado")
    //Se prueba con el tipo de colegio femenino
    public void colegiosPorTipoTest() {
        // Given ...
        String endpoint = "/api/Femenino/colegio/";
        // When ...
        ResponseEntity<List> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, List.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());

    }


    @Test()
    @DisplayName("GET /api/{tipo}/colegio/")
    //Se prueba con el tipo PEPITO que no existe -> ME DEVOLVERIA UNA LISTA VACIA -> por eso el expected y .OK
    public void colegiosPorTipoErrorTest() {
        // Given ...
        String endpoint = "/api/PEPITO/colegio/";
        ArrayList expected = new ArrayList();
        // When ...
        ResponseEntity<List> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, List.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(expected, response.getBody());

    }

    //TEST DE LOS ENDPOINTS DE PISO
    @Test()
    @DisplayName("GET /api/{inquilinos}/{ciudadId}/piso/ retorna una lista de los pisos que tienen esos inquilinos y son de esa ciudad")
    //Se prueba con 2 inquilinos y ciudad 1 (Madrid)
    public void pisosPorInquilinosTest() {
        // Given ...
        String endpoint = "/api/2/1/piso/";
        // When ...
        ResponseEntity<List> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, List.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());

    }


    @Test()
    @DisplayName("GET /api/{inquilinos}/{ciudadId}/piso/")
    //Se prueba con 6 inquilinos y ciudad 4 (no existe) -> da un OK porque mi expected es un []
    public void pisosPorInquilinosErrorTest() {
        // Given ...
        String endpoint = "/api/6/4/piso/";
        ArrayList expected = new ArrayList();
        // When ...
        ResponseEntity<List> response = restTemplate.getForEntity("http://localhost:8080" + endpoint, List.class);
        // Then ...
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assertions.assertEquals(expected, response.getBody());

    }

}