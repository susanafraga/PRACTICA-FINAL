package edu.comillas.icai.gitt.pat.spring.jpa.repositorio;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Carrera;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Universidad;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RepoUniversidad extends CrudRepository<Universidad, Long> {
    List<Universidad> findByCiudadId(Long ciudad_id);

    @Query(nativeQuery = true, value = "SELECT C.UNIVERSIDAD FROM UNIVERSIDAD C WHERE C.ID=:universidadId")
    String buscarPorId(Long universidadId);



}
