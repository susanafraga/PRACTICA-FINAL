package edu.comillas.icai.gitt.pat.spring.jpa.repositorio;


import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Piso;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RepoPiso extends CrudRepository<Piso, Long> {
    List<Piso> findByInquilinos(Long inquilinos);

    List<Piso> findByInquilinosAndCiudadId(Long inquilinos, Long ciudadId);

    @Query(nativeQuery = true, value = "SELECT C.NOMBRE FROM PISO C WHERE C.ID=:pisoId")
    String buscarPorId(Long pisoId);
}
