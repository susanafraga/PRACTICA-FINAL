package edu.comillas.icai.gitt.pat.spring.jpa.controlador;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Carrera;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Universidad;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioCarrera;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioUniversidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CarreraControlador {

    @Autowired
    ServicioCarrera servicio;

    @GetMapping(path = "/api/carrera/{carreraId}/")
    public String getNombreCarrera(@PathVariable Long carreraId){return servicio.getNombreCarrera(carreraId);}

}

