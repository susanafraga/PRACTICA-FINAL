package edu.comillas.icai.gitt.pat.spring.jpa.servicio;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoColegio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioColegio {

    @Autowired
    RepoColegio repoColegio;

    public List<Colegio> colegios(String tipo){ return repoColegio.findByTipo(tipo);}

    public List<Colegio> colegiosPorCiudad(String tipo, Long ciudadId) {
        return repoColegio.findByTipoAndCiudadId(tipo, ciudadId);
    }

    public String getNombreCole(Long colegioId) { return repoColegio.buscarPorId(colegioId);
    }
}
