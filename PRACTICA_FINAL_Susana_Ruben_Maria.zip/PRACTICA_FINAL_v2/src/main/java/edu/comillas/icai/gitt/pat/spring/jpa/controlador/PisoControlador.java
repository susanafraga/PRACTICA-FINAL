package edu.comillas.icai.gitt.pat.spring.jpa.controlador;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Piso;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Universidad;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioPiso;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioUniversidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PisoControlador {

    @Autowired
    ServicioPiso servicio;


    @GetMapping(path = "/api/{inquilinos}/piso/")
    public List<Piso> pisos(@PathVariable Long inquilinos){
        return servicio.pisos(inquilinos);
    }

    //ESTO ES PARA LA SOLICITUD
    @GetMapping(path = "/api/{inquilinos}/{ciudadId}/piso/")
    public List<Piso> pisosPorCiudad(@PathVariable Long inquilinos, @PathVariable Long ciudadId){
        return servicio.pisosPorCiudad(inquilinos, ciudadId);
    }

    //ESTO ES PARA QUE EN LA TABLA DE SOLICITUD APAREZCA EL NOMBRE Y NO SU ID
    @GetMapping(path = "/api/piso/{pisoId}/")
    public String getNombrePiso(@PathVariable Long pisoId){return servicio.getNombrePiso(pisoId);}


}

