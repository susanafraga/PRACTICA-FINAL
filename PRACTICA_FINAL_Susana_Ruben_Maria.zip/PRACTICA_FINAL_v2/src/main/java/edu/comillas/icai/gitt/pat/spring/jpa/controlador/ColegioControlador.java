package edu.comillas.icai.gitt.pat.spring.jpa.controlador;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Piso;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Universidad;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioColegio;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioUniversidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ColegioControlador {

    @Autowired
    ServicioColegio servicio;


    @GetMapping(path = "/api/{tipo}/colegio/")
    public List<Colegio> colegios(@PathVariable String tipo){
        return servicio.colegios(tipo);
    }


    //ESTE SE USA EN LA SOLICITUD
    @GetMapping(path = "/api/{tipo}/{ciudadId}/colegio/")
    public List<Colegio> colegiosPorCiudad(@PathVariable String tipo, @PathVariable Long ciudadId){
        return servicio.colegiosPorCiudad(tipo, ciudadId);
    }

    //ESTO ES PARA QUE EN LA TABLA DE SOLICITUD APAREZCA EL NOMBRE Y NO SU ID
    @GetMapping(path = "/api/colegio/{colegioId}/")
    public String getNombreColegio(@PathVariable Long colegioId){return servicio.getNombreCole(colegioId);}

}

