package edu.comillas.icai.gitt.pat.spring.jpa.repositorio;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Solicitud;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Usuario;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RepoSolicitud extends CrudRepository<Solicitud, Long> {

    List<Solicitud> findByUsuarioId(Long userId);

    //Query para encontrar aquellos elementos que haya seleccionado el usuario registrado
}
