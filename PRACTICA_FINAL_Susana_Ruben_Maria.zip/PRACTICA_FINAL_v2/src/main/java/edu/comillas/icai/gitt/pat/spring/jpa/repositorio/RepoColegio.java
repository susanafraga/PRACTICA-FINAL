package edu.comillas.icai.gitt.pat.spring.jpa.repositorio;


import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RepoColegio extends CrudRepository<Colegio, Long> {
    List<Colegio> findByTipo(String tipo);

    List<Colegio> findByTipoAndCiudadId(String tipo, Long ciudadId);

    @Query(nativeQuery = true, value = "SELECT C.NOMBRE FROM COLEGIO C WHERE C.ID=:colegioId")
    String buscarPorId(Long colegioId);

}
