package edu.comillas.icai.gitt.pat.spring.jpa.controlador;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Solicitud;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Usuario;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoUsuario;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioColegio;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioSolicitud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
public class SolicitudControlador {

    @Autowired
    ServicioSolicitud servicioSolicitud;

    @Autowired
    RepoUsuario repoUsuario;

    @PostMapping("/api/solicitudes")
    public Solicitud creaSolicitud(@RequestBody Solicitud solicitudNueva,
                                   @RequestHeader("Authorization") String credenciales){
        if (repoUsuario.findByCredenciales(credenciales) == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);

        Solicitud solicitudCreada = servicioSolicitud.crearSolicitud(solicitudNueva);

        return solicitudCreada;
    }

    @GetMapping("/api/solicitudes/{userId}")
    @ResponseStatus(HttpStatus.OK)
    public List<Solicitud> getSolicitudUser(@PathVariable Long userId){

        return servicioSolicitud.getSolicitudUsuario(userId);
    }


/*
    @GetMapping("/api/solicitudes") //para hacer el login
    public Iterable<Solicitud> solicitudes(Long id) {
        return servicio.getSolicitudUsuario(id);
    }

    @PostMapping("/api/solicitudes")
    public Solicitud crearSolicitud(@RequestBody Solicitud solicitud) {
        return servicio.crearSolicitud(solicitud);
    }*/


}

