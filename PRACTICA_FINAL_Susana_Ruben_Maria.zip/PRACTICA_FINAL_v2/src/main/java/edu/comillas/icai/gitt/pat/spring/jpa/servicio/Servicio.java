package edu.comillas.icai.gitt.pat.spring.jpa.servicio;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Piso;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Universidad;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoColegio;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoPiso;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoUniversidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Servicio {
    @Autowired
    RepoUniversidad repoUniversidad;
    @Autowired
    RepoPiso repoPiso;
    @Autowired
    RepoColegio repoColegio;


    public List<Universidad> universidades(Long ciudadId){ return repoUniversidad.findByCiudadId(ciudadId);}
    public List<Colegio> colegios(String tipo){ return repoColegio.findByTipo(tipo);}
    public List<Piso> pisos(Long inquilinos){ return repoPiso.findByInquilinos(inquilinos);}
}
