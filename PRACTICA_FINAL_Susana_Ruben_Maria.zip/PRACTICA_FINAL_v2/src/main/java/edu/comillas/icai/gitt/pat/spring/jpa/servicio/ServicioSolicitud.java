package edu.comillas.icai.gitt.pat.spring.jpa.servicio;


import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Solicitud;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoColegio;
import edu.comillas.icai.gitt.pat.spring.jpa.repositorio.RepoSolicitud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class ServicioSolicitud {

    @Autowired
    RepoSolicitud repoSolicitud;

    //PARA EL POST
    public Solicitud crearSolicitud(Solicitud nuevaSolicitud) {
        //Actualizo solicitud
        Solicitud solicitud = repoSolicitud.save(nuevaSolicitud);

        return solicitud;
    }

    //PARA OBTENER LA SOLICITUD DEL USER
    public List<Solicitud> getSolicitudUsuario(Long userId){
       return repoSolicitud.findByUsuarioId(userId);
    }

}
