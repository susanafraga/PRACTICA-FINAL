package edu.comillas.icai.gitt.pat.spring.jpa.entidad;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.sql.Timestamp;
@Entity
public class Universidad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false, unique = true) public String universidad;
    @Column(nullable = false) public Long ciudadId;
    @Column(nullable = false, length=3000) public String url;
    @Column(nullable = false, length=3000) public String web;
}