package edu.comillas.icai.gitt.pat.spring.jpa.entidad;
import jakarta.persistence.*;

import java.sql.Timestamp;
@Entity
public class Ciudad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false, unique = true) public String ciudad;
}