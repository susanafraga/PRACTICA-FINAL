package edu.comillas.icai.gitt.pat.spring.jpa.repositorio;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Carrera;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface RepoCarrera extends CrudRepository<Carrera, Long> {

    @Query(nativeQuery = true, value = "SELECT * FROM CARRERA C WHERE C.UNIVERSIDAD_ID=:universidadId")
    Iterable<Carrera> buscarPorUniversidadId(Long universidadId);

    @Query(nativeQuery = true, value = "SELECT C.CARRERA FROM CARRERA C WHERE C.ID=:carreraId")
    String buscarPorId(Long carreraId);
}
