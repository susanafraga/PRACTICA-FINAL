package edu.comillas.icai.gitt.pat.spring.jpa.entidad;
import jakarta.persistence.*;

import java.sql.Timestamp;
@Entity
public class Piso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false, unique = true) public String nombre;
    @Column(nullable = false) public Long ciudadId;
    @Column(nullable = false) public Long inquilinos;
}