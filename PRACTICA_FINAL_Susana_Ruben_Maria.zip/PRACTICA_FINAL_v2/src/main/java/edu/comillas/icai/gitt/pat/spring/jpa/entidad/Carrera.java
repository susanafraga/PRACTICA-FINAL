package edu.comillas.icai.gitt.pat.spring.jpa.entidad;
import jakarta.persistence.*;

import java.sql.Timestamp;
@Entity
@Table(uniqueConstraints={@UniqueConstraint(columnNames = {"universidadId", "rama", "carrera"})})
public class Carrera {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false) public Long universidadId;
    @Column(nullable = false) public String rama;
    @Column(nullable = false) public String carrera;
}