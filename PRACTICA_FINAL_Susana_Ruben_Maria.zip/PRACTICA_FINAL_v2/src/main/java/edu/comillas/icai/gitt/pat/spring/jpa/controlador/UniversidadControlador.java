package edu.comillas.icai.gitt.pat.spring.jpa.controlador;

import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Carrera;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Colegio;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Piso;
import edu.comillas.icai.gitt.pat.spring.jpa.entidad.Universidad;
import edu.comillas.icai.gitt.pat.spring.jpa.servicio.ServicioUniversidad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UniversidadControlador {

    @Autowired
    ServicioUniversidad servicio;

    @GetMapping(path = "/api/{ciudadId}/universidad/")
    public List<Universidad> universidades(@PathVariable Long ciudadId) {
        return servicio.universidades(ciudadId);
    }

    //GET la carrera en funcion de la universidad
    @GetMapping(path = "/api/universidad/{universidadId}/carrera")
    public Iterable<Carrera> carreras(@PathVariable Long universidadId ) {
        return servicio.carreras(universidadId);
    }

    @GetMapping(path = "/api/universidad/{universidadId}/")
    public String getNombreUniversidad(@PathVariable Long universidadId){return servicio.getNombreUniversidad(universidadId);}



}

