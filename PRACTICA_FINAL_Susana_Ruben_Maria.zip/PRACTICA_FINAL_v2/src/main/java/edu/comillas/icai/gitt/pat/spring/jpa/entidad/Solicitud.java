package edu.comillas.icai.gitt.pat.spring.jpa.entidad;
import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
public class Solicitud {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) public Long solicitudId;
    @Column(nullable = false) public Long usuarioId;
    @ManyToOne() public Universidad universidad;
    @ManyToOne() public Carrera carrera;
    @Column(nullable = false) public String tipo;
    @ManyToOne() public Colegio colegio;
    @ManyToOne() public Piso piso;
    @Column(nullable = false) public String estado;

}