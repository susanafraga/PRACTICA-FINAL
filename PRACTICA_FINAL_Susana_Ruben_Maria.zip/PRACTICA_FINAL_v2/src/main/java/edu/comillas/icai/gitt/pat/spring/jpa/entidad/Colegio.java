package edu.comillas.icai.gitt.pat.spring.jpa.entidad;
import jakarta.persistence.*;

import java.sql.Timestamp;
@Entity
public class Colegio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false, unique = true) public String nombre;
    @Column(nullable = false) public Long ciudadId;
    @Column(nullable = false) public String tipo;
    @Column(nullable = false) public String descripcion;
    @Column(nullable = false, length=3000) public String url;
    @Column(nullable = false, length=3000) public String web;

    public String ciudad;
}