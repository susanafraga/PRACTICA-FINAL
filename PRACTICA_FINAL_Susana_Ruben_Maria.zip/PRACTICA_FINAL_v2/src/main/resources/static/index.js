// TODO: añadir la lógica común y/o inicial de tu aplicación

var usuarioLogado;
var usuarioId;
var universidadId;
var carreraId;
var tipo;
var colegioId;
var pisoId;
var estado;
var ciudadId;
var nombreUni;
var nombreCarrera;
var nombreCole;
var nombrePiso;

function incrementaCreaContador(contador) {
  peticionApi(`/api/contadores/${contador}/incremento/1`, 'PUT')
    .then(respuesta => respuesta.json())
    .then(json => {
      if (json.status === 404) {
        return peticionApi(`/api/contadores`, 'POST', {nombre: contador, valor: 1});
      } else if (json.status) {
        throw json;
      }
    }).then(respuesta => {
      if (respuesta && respuesta.status !== 201) { throw respuesta; }
    }).catch(error => {
      console.error(`Error inesperado al incrementar contador "${contador}".`, error);
    });
}
