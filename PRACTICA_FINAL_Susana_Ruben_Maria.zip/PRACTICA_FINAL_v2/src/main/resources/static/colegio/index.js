document.getElementById('desplegableTipo').onchange = function () {
           var desplegable = document.getElementById("desplegableTipo");
           var seleccion = desplegable.value;
           var tabla = document.getElementById('colegios');
           var ciudad;
           fetch("/api/"+seleccion+"/colegio/")
           .then(response => response.json())
           .then(json => {
              tabla.innerHTML += `<tr><td>Nombre</td><td>Ciudad</td><td>Descripción</td><td>Imagen fachada</td></tr>`;
              json.forEach(e => {
                   if(e.ciudadId == 1){
                        ciudad= "Madrid";
                   }
                   else if(e.ciudadId == 2){
                        ciudad = "Barcelona";
                   }
                   else if(e.ciudadId == 3){
                        ciudad = "Valencia"
                   }
                   tabla.innerHTML += `<tr><td><a href=${e.web}>${e.nombre}</a></td><td>${ciudad}</td><td>${e.descripcion}</td><td><img src=${e.url}></td></tr>`;
              })
           });
           tabla.innerHTML='';
           //<img src=${e.url}</a>
           //<img src="piscina.webp" alt="Piscina">
           //<a href=${e.web}>${e.nombre}</a>
}