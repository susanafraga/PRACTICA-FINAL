
document.getElementById('desplegableCiudad').onchange = function () {
           var desplegable = document.getElementById("desplegableCiudad");
           var seleccion = desplegable.value;
           var tabla = document.getElementById('universidades');
           fetch("/api/"+seleccion+"/universidad/")
           .then(response => response.json())
           .then(json => {
              tabla.innerHTML += `<tr><td>Nombre</td><td>Mapa</td><td>Página web</td></tr>`;
              json.forEach(e => {
                   tabla.innerHTML += `<tr><td>${e.universidad}</td><td>${e.url}</td><td><a href=${e.web}>Página web oficial</a></td></tr>`;
              })
           });
           tabla.innerHTML='';
};
