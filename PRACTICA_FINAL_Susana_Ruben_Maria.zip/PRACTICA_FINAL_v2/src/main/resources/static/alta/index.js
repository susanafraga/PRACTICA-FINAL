// TODO: añadir lógica particular de esta página


console.log(`El usuario actualmente logado es: ${usuarioLogado}`);
//if usuarioLogado == null
    //disabled


document.getElementById("alta").onclick = function() {
  const resultado = document.getElementById("resultado-alta");
  const email = document.getElementById("email");
  const clave = document.getElementById("clave-alta");
  const claveConf = document.getElementById("clave-alta-conf");
  if (!clave.value || !email.value) {
    resultado.textContent = 'El email y la clave son obligatorios.';
    return;
  }
  if (clave.value !== claveConf.value) {
    clave.value = '';
    claveConf.value = '';
    resultado.textContent = 'Las claves no coinciden, vuelve a introducirlas.';
    return;
  }

  //peticion de la api
  peticionApi(`/api/usuarios`, 'POST', {email: email.value}, email.value, clave.value)
    .then(respuesta => respuesta.json())
    .then(json => {
      if (json.email) {
        email.value = '';
        clave.value = '';
        claveConf.value = '';
        resultado.textContent = `Usuario ${email.value} registrado. Ya puedes logarte con él.`;
      } else if (json.status === 409) {
        resultado.textContent = 'Ya existe un usuario registrado con mismo email.';
      } else {
        throw json;
      }
    }).catch(error => {
      resultado.textContent = 'Error inesperado al hacer el alta.';
      console.error(`Error inesperado al hacer el alta`, error);
    });
};