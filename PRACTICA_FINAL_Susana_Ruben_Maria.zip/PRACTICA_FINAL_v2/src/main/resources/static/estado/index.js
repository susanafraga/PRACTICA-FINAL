document.getElementById("entrar").onclick = function() {
  peticionApi(`/api/usuarios`, null, null, document.getElementById("usuario").value, document.getElementById("clave").value)
    .then(respuesta => respuesta.json())
    .then(json => {
      document.getElementById("login").hidden = true;
      document.getElementById("estado").hidden = false;
      if (json.email) {
        document.getElementById("accion").value = 'Salir';
        document.getElementById("accion2").hidden = false;
        document.getElementById("mensaje").textContent = json.email;
        json.clave = document.getElementById("clave").value;
        usuarioLogado = json;
      } else if (json.status === 401) {
        document.getElementById("accion").value = 'Volver';
        document.getElementById("accion2").hidden = true;
        document.getElementById("mensaje").textContent = 'Credenciales incorrectas';
      } else {
        throw json;
      }
    }).catch(error => {
      document.getElementById("login").hidden = true;
      document.getElementById("estado").hidden = false;
      document.getElementById("accion").value = 'Reintentar';
      document.getElementById("mensaje").textContent = 'Error inesperado';
      console.error(`Error inesperado al hacer login`, error);
    });
};

document.getElementById("accion").onclick = function() {
  document.getElementById("login").hidden = false;
  document.getElementById("estado").hidden = true;
  document.getElementById("usuario").value = '';
  document.getElementById("clave").value = '';
  usuarioLogado = null;
};


document.getElementById("usuario").addEventListener("keyup", function(event) {
  if(event.key === 'Enter') {
    event.preventDefault();
    document.getElementById("clave").focus();
  }
});

document.getElementById("clave").addEventListener("keyup", function(event) {
  if(event.key === 'Enter') {
    event.preventDefault();
    document.getElementById("entrar").click();
  }
});

const tablaSolicitud = document.getElementById("solicitud");

//GET
document.getElementById("muestraResumen").onclick = function (){
    fetch(`/api/solicitudes/${usuarioLogado.id}`)
    .then(response => response.json())
    .then(json => {
      console.log(json);
      tablaSolicitud.innerHTML='<tr><th>Usuario</th><th>Universidad</th><th>Carrera</th><th>Colegio</th><th>Piso</th><th>Estado</th></td></thead>';
      json.forEach(s => {
        tablaSolicitud.innerHTML += `<tr><td>${usuarioLogado.email}</td><td>${s.universidad.universidad}</td>
                                    <td>${s.carrera.carrera} ${s.carrera.rama}</td><td>${s.colegio && s.colegio.nombre || ""}</td>
                                    <td>${s.piso && s.piso.nombre || ""}</td><td>${s.estado}</td></tr>`;
      });
    });
}
