ciudadId = document.getElementById("ciudad").value;
document.getElementById('ciudad').onchange = function (e) {
           ciudadId = e.target.value;
           var lista = document.getElementById('universidades');
           fetch(`/api/${ciudadId}/universidad/`)
           .then(response => response.json())
           .then(json => {
              json.forEach(e => {
                    lista.innerHTML += `<option value = ${e.id}>${e.universidad}</option>`;
              })
           });
           lista.innerHTML='';
};

function alertaClick(pruebaId){
    carreraId = pruebaId;
}

universidadId = document.getElementById("universidades").value;
document.getElementById('universidades').onchange = function (e) {
           universidadId = e.target.value;
           var tabla = document.getElementById('carreras');
           fetch("/api/universidad/"+universidadId+"/carrera")
           .then(response => response.json())
           .then(json => {
              tabla.innerHTML += `<tr><td>Selección</td><td>Carrera</td><td>Rama</td></tr>`;
              json.forEach(e => {
                    tabla.innerHTML += `<tr><td><input data-carrera-id="${e.id}" type=checkbox value=${e.id}></input></td><td>${e.carrera}</td><td>${e.rama}</td></tr>`;
                  document.querySelectorAll('[data-carrera-id]').forEach(b => b.onclick = () => alertaClick(b.dataset.carreraId));
                  });
           });
           tabla.innerHTML='';
};



