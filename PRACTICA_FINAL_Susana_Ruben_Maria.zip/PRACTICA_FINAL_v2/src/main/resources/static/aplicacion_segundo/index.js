
//PARA IR COMPROBANDO QUE ESTA BIEN
console.log("TU ID DE uni es " + universidadId);
console.log("Tu ID DE city es " + ciudadId);
console.log("TU ID DE USUARIO ES " + usuarioLogado.id);
console.log("TU ID DE CARRERA ES " + carreraId);



//FETCH PARA CONSEGUIR EL NOMBRE DE LA CARRERA -> NO SE USA, PERO LO DEJAMOS POR SI ACASO
fetch(`/api/carrera/${carreraId}/`)
    .then(response => response.text())
    .then(text => {
    console.log("HE LLEGADO AL FETCH DE CARRERA" + text);
    nombreCarrera = text;
  });


//FETCH PARA CONSEGUIR EL NOMBRE DE LA CARRERA
fetch(`/api/universidad/${universidadId}/`)
    .then(response => response.text())
    .then(text => {
    console.log("HE LLEGADO AL FETCH DE UNI " + text);
    nombreUni = text;
  });


document.getElementById('alojamiento').onchange = function () {
    var desplegable = document.getElementById("alojamiento");
    tipo = desplegable.value;
    if(tipo=="piso"){
        document.getElementById("pisos").hidden = false;
        document.getElementById("colegios").hidden = true;
    }
    else if(tipo=="colegio_mayor"){
        document.getElementById("colegios").hidden = false;
        document.getElementById("pisos").hidden = true;
    }

};

function alertaClick(pruebaId){
    colegioId = pruebaId;
}

document.getElementById('colegiosDesplegable').onchange = function () {
           var desplegable = document.getElementById("colegiosDesplegable");
           colegioId = desplegable.value;
           var tabla = document.getElementById('colegio_lista');
           fetch("/api/"+colegioId+"/"+ciudadId+"/colegio/")
           .then(response => response.json())
           .then(json => {
              tabla.innerHTML += `<tr><td>Selección</td><td>Nombre</td><td>Ciudad</td><td>Descripción</td><td>Imagen fachada</td></tr>`;
              json.forEach(e => {
                   if(e.ciudadId == 1){
                        ciudad= "Madrid";
                   }
                   else if(e.ciudadId == 2){
                        ciudad = "Barcelona";
                   }
                   else if(e.ciudadId == 3){
                        ciudad = "Valencia"
                   }

                    tabla.innerHTML += `<tr><td><input data-colegio-id="${e.id}" type=checkbox value=${e.id}></input></td><td><a href=${e.web}>${e.nombre}</a></td><td>${ciudad}</td>
                    <td>${e.descripcion}</td><td><img src=${e.url}></td></tr>`;
                    document.querySelectorAll('[data-colegio-id]').forEach(b => b.onclick = () => alertaClick(b.dataset.colegioId));
              })
           });
           tabla.innerHTML='';
};

function alertaClickPiso(pruebaId){
    pisoId = pruebaId;
}

document.getElementById('pisosDesplegable').onchange = function () {
           var desplegable = document.getElementById("pisosDesplegable");
           var inquilinos = desplegable.value;
           var tabla = document.getElementById('pisos_lista');
           fetch(`/api/${inquilinos}/${ciudadId}/piso/`)
           .then(response => response.json())
           .then(json => {
              json.forEach(e => {
                 tabla.innerHTML += `<tr><td><input data-piso-id="${e.id}" type=checkbox value=${e.id}></input></td><td>${e.nombre}</td></tr>`;
                 document.querySelectorAll('[data-piso-id]').forEach(b => b.onclick = () => alertaClickPiso(b.dataset.pisoId));
              })
           });
           tabla.innerHTML='';
};


