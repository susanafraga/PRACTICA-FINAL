document.getElementById('desplegableInquilinos').onchange = function () {
           var desplegable = document.getElementById("desplegableInquilinos");
           var seleccion = desplegable.value;
           var tabla = document.getElementById('pisos');
           fetch("/api/"+seleccion+"/piso/")
           .then(response => response.json())
           .then(json => {
              json.forEach(e => {
                   tabla.innerHTML += `<tr><td>${e.nombre}</td></tr>`;
              })
           });
           tabla.innerHTML='';
};
