// TODO: añadir lógica particular de esta página

incrementaCreaContador('perfil');

console.log(`El usuario actualmente logado es: ${usuarioLogado}`);