

incrementaCreaContador('inicio');

const resultado = document.getElementById("resultado-estadisticas");
document.getElementById("consultar").onclick = function() {
  fetch(`/api/contadores/${contador.value}`)
    .then(respuesta => respuesta.json())
    .then(json => {
      if (json.valor !== undefined) {
        resultado.textContent = `Actualmente un total de ${json.valor} se han interesado en nuestra web.`;
      } else if (json.status === 404) {
        resultado.textContent = `El contador "${contador.value}" no existe todavía.`;
      } else {
        throw json;
      }
    })
    .catch(error => {
      resultado.textContent = `Error inesperado al consultar contador "${contador.value}".`;
      console.error(resultado.textContent, error);
    });
};

document.getElementById("borrar").onclick = function() {
  fetch(`/api/contadores/${contador.value}`, 'DELETE')
    .then(respuesta => {
      if (respuesta.status === 200) {
        resultado.textContent = `El contador "${contador.value}" ha sido borrado.`;
      } else {
        throw respuesta;
      }
    })
    .catch(error => {
      resultado.textContent = `Error inesperado al borrar contador "${contador.value}".`;
      console.error(resultado.textContent, error);
    });
};