const tablaSolicitud = document.getElementById("solicitud");

console.log("Tu nombre uni es " + nombreUni);
console.log("Tu nombre carrera es " + nombreCarrera);

//POST
let datos = {
    usuarioId: usuarioLogado.id,
    universidad: { id: universidadId },
    carrera: {id: carreraId },
    tipo: tipo,
    colegio: colegioId ? {id: colegioId} : null,
    piso: pisoId ? {id: pisoId} : null,
    estado: "PENDIENTE"
};

const opciones = {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + window.btoa(unescape(encodeURIComponent(`${usuarioLogado.email}:${usuarioLogado.clave}`)))
    },
    body: JSON.stringify(datos),
};

document.getElementById("enviarSolicitud").onclick = async function (){

    const peticion = await fetch(`/api/solicitudes`,opciones);
    if(peticion.ok){
        console.log(await peticion.json());
    } else{
        console.log(peticion);
    }

}


//GET
document.getElementById("muestraResumen").onclick = function (){
    document.getElementById("titulo").hidden = false;
    fetch(`/api/solicitudes/${usuarioLogado.id}`)
    .then(response => response.json())
    .then(json => {
      console.log(json);
      tablaSolicitud.innerHTML='<tr><th>Usuario</th><th>Universidad</th><th>Carrera</th><th>Colegio</th><th>Piso</th><th>Estado</th></td></thead>';
      json.forEach(s => {
        tablaSolicitud.innerHTML += `<tr><td>${usuarioLogado.email}</td><td>${s.universidad.universidad}</td>
                                    <td>${s.carrera.carrera} ${s.carrera.rama}</td><td>${s.colegio && s.colegio.nombre || ""}</td>
                                    <td>${s.piso && s.piso.nombre || ""}</td><td>${s.estado}</td></tr>`;
      });
    });
}
