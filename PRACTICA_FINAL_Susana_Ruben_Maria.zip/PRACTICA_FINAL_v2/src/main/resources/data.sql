INSERT INTO usuario (email, credenciales, rol) VALUES ('admin@e.m', 'Basic YWRtaW5AZS5tOmFkbWlu', 'ADMIN');
INSERT INTO usuario (email, credenciales, rol) VALUES ('boss@e.m', 'Basic Ym9zc0BlLm06Ym9z', 'USER');
INSERT INTO usuario (email, credenciales, rol) VALUES ('user@e.m', 'Basic dXNlckBlLm06dXNlcg==', 'USER');
--Autoprovisionar con universidades, pisos, colegios mayores. Dentro de cada carpeta metemos las fotos que queramos utilizar

INSERT INTO CIUDAD (ciudad) VALUES ('Madrid');
INSERT INTO CIUDAD (ciudad) VALUES ('Barcelona');
INSERT INTO CIUDAD (ciudad) VALUES ('Valencia');

INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Padre Poveda', 1, 'Femenino', 'Centro universitario femenino adscrito a la complutense dirigido por la institucion Teresiana','https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Colegio_Mayor_Padre_Poveda_%28Madrid%29_01.jpg/2560px-Colegio_Mayor_Padre_Poveda_%28Madrid%29_01.jpg','https://www.cmppoveda.org/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Santa Monica', 1, 'Femenino', 'Centro universitario femenino adscrito a la complutense dirigido por la Congregacion de Agustinas Misioneras', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/S-Monica4-500x374.jpg','https://cmumonica.es/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor San Pablo', 1, 'Masculino', 'Centro universitario masculino adscrito al CEU fundado en 1944', 'https://www.acdp.es/wp-content/uploads/colegio-mayor.jpg','https://www.cmsanpablo.es/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Jaime Del Amo', 1, 'Masculino', 'Centro universitario masculino adscrito a la complutense dirigido por los misioneros Claretianos','https://upload.wikimedia.org/wikipedia/commons/a/a2/Madrid_-_Ciudad_Universitaria%2C_Colegio_Mayor_Jaime_del_Amo_%28UCM%29_5.jpg','https://www.jaimedelamo.org/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Loyola', 1, 'Mixto', 'Centro universitario dirigido por los Jesuitas', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/002-500x334.jpg','https://cmuloyola.org/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Mater Salvatoris',2, 'Femenino', 'Colegio Universitario femenino fundado por la Compañia del Salvador', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/mater-fachada-1.jpg','https://barcelona.matersalvatoris.org/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Bonaigua',2, 'Femenino', 'Centro universitario femenino adscrito a la Universidad de Barcelona', 'https://bonaigua.es/wp-content/uploads/porque-04.jpg','https://bonaigua.es/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Monterols',2, 'Maculino', 'Centro Universitario masculino adscrito a la Universidad de Barcelona', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/CMU_Monterols.jpg','https://www.consejocolegiosmayores.es/directorio/6201/colegio-mayor-monterols/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Pedralbes',2, 'Masculino', 'Centro Universitario masculino fundado por el Opus Dei', 'https://dondememeto.com/sites/default/files/styles/large/public/field/image/residencias/1portada_2.jpg?itok=FrVVraNS','https://www.cmupedralbes.es/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Àgora',2, 'Mixto', 'Centro universitario adscrito a la Universidad de Barcelona', 'https://x.cdrst.com/foto/hotel-sf/6a7b/granderesp/agora-bcn-residencia-universitaria-internacional-general-caa0e40.jpg','https://www.agorabcn.com/es/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Saomar',3, 'Femenino', 'Centro universitario femenino adscrito a la Univerdidad de Valencia dirigido por el Opues Dei', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/Foto-fachada-Saomar.jpg','https://saomar.com/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor La Asuncion',3, 'Femenino', 'Centro universitario femenino en el Campus de la Universidad de Valencia', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2020/02/ccmm-anzur-04-1.jpg','https://cmlaasuncion.es/?gclid=CjwKCAjwjYKjBhB5EiwAiFdSfvm-V5m1X02nKnFRO7330QmtKiSUs7MzCnTQDwJeHLin36fVgaXUARoCw1AQAvD_BwE');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Albalat',3, 'Maculino', 'Centro Universitario masculino en el centro de la Universidad de Valencia', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/Albalat1-1.jpg','https://www.colegiomayoralbalat.com/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Alameda',3, 'Masculino', 'Centro universitario masculino adscrito a la Universidad de Valencia', 'https://www.consejocolegiosmayores.es/wp-content/uploads/2016/12/colegio-mayor-vitrina.jpg','http://cmalameda.es/');
INSERT INTO COLEGIO (nombre, ciudad_id, tipo, descripcion, url, web) VALUES ('Colegio Mayor Galileo-Galilei',3, 'Mixto', 'Centro universitario adscrito a la Universidad de Valencia', 'https://dondememeto.com/sites/default/files/field/image/residencias/exterior_desde_avenida.jpg','https://www.galileogalilei.com/');


INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Pontificia Comillas', 1, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3037.046566110919!2d-3.7141455240922854!3d40.42996777143751!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd42286644252c17%3A0xa0e16ec00632c7a1!2sUniversidad%20Pontificia%20Comillas!5e0!3m2!1ses!2ses!4v1684088482458!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.comillas.edu/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('CUNEF', 1, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.0682587952133!2d-3.722713424091129!3d40.45162617143399!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4228894f8fb54d%3A0xa6bd21728d5819ed!2sCUNEF!5e0!3m2!1ses!2ses!4v1684088524507!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.cunef.edu/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Francisco de Vitoria', 1, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.603092314038!2d-3.836668524091739!3d40.43978687143588!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4185d02b000001%3A0x9b035d2695ce702c!2sUniversidad%20Francisco%20de%20Vitoria!5e0!3m2!1ses!2ses!4v1684088555861!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.ufv.es/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad CEU San Pablo', 1, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.4732413249276!2d-3.720280324091584!3d40.44266157143534!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422845f7342fab%3A0x38877dd3b6f3bfd!2sUniversidad%20CEU%20San%20Pablo!5e0!3m2!1ses!2ses!4v1684088594209!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.uspceu.com/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Internacional de Cataluna', 2, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2992.5436205547876!2d2.1209645759581655!3d41.405716571297525!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4911bc812913d%3A0xc98256cefd62134!2sUIC%20Barcelona!5e0!3m2!1ses!2ses!4v1684097525101!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.uic.es/es');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad CEU Abat Oliba', 2, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2992.3423426497106!2d2.1238529759583797!3d41.41008667129698!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a49817c5f1265f%3A0xb3a2d73f6bbbec73!2sUniversidad%20Abat%20Oliba%20CEU!5e0!3m2!1ses!2ses!4v1684097558591!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.uaoceu.es/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Ramon Llull', 2, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2992.2578533408227!2d2.128645075958496!3d41.4119209712968!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a49810a17a0197%3A0xa2be1e72b186beb6!2sUniversidad%20Ramon%20Llull!5e0!3m2!1ses!2ses!4v1684097583625!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.url.edu/ca');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad UOC', 2, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d47876.131090215225!2d2.0900204033094223!3d41.41191359427441!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a4a33d25b76e7f%3A0xf77b18819205bfdc!2sUOC%20Universitat%20Oberta%20de%20Catalunya!5e0!3m2!1ses!2ses!4v1684097624370!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.uoc.edu/portal/es/index.html');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad CEU Cardenal Herrera', 3, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1585034.7807757966!2d-1.7076931744229753!3d39.11168219762656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd60443d9d690821%3A0x4350af9d2ed06c42!2sUniversidad%20CEU%20Cardenal%20Herrera%20-%20Campus%20Alfara%20del%20Patriarca!5e0!3m2!1ses!2ses!4v1684097670982!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.uchceu.es/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Europea de Valencia', 3, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6159.140281730093!2d-0.37565255525238667!3d39.47903878642261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd6048bdbd9bfc6d%3A0x5aecfdfaf70ef6b9!2sUniversidad%20Europea%20de%20Valencia!5e0!3m2!1ses!2ses!4v1684097698144!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://universidadeuropea.com/conocenos/valencia/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Catolica de Valencia', 3, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24637.336075243762!2d-0.4216156256836262!3d39.47685080000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd604f494b3ed657%3A0x621c0c295d667848!2sCampus%20de%20Valencia%20de%20la%20Universidad%20Cat%C3%B3lica!5e0!3m2!1ses!2ses!4v1684097725649!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.ucv.es/');
INSERT INTO UNIVERSIDAD (universidad, ciudad_id, url, web) VALUES ('Universidad Internacional de Valencia', 3, '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3079.902616803453!2d-0.3745548241408451!3d39.471528671607224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd604914790dddab%3A0xe5f9d026db389ab7!2sUniversidad%20Internacional%20de%20Valencia%20(VIU)!5e0!3m2!1ses!2ses!4v1684097749977!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>','https://www.universidadviu.com/es/');


INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (1,'Tecnologica','Ingenieria Industrial');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (1,'Sociales','Derecho y ADE');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (1,'Biosanitaria','Psicología');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (2,'Tecnologica','Ingenieria Matematica e Informatica');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (2,'Sociales','Derecho y Inteligencia Artificial');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (2,'Sociales','Derecho y ADE');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (3,'Biosanitaria','Medicina');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (3,'Sociales','Periodismo y Relaciones Internacionales');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (3,'Tecnologica','Ingenieria Informática');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (4,'Biosanitaria','Medicina');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (4,'Sociales','Derecho, Criminologia y Seguridad');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (4,'Biosanitaria','Enfermeria');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (9,'Biosanitaria','Odontologia');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (9,'Sociales','Educacion Infantil y Educacion Primaria');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (9,'Sociales','Cine');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (10,'Biosanitaria','Psicología');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (10,'Sociales','Periodismo y Ciencias Políticas');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (10,'Sociales','Derecho + International Law');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (11,'Biosanitaria','Biotecnologíaa + ADE');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (11,'Tecnologica','Ingeniería + ADE');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (11,'Sociales','Marketing');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (12,'Sociales','Economia y Empresa');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (12,'Sociales','Finanzas');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (12,'Biosanitaria','Nutrición y Salud');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (5,'Biosanitaria','Psioterapia');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (5,'Tecnologica','Arquitectura');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (5,'Sociales','Marketing + ADE');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (6,'Biosanitaria','Nutrición y Dietética');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (6,'Tecnologica','Ciencia de datos');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (6,'Sociales','Relaciones laborales y Recursos humanos');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (7,'Biosanitaria','Podología');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (7,'Biosanitaria','Veterinaria');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (7,'Sociales','Multimedia y Artes Visuales');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (8,'Biosanitaria','Logopedia');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (8,'Tecnologica','Física');
INSERT INTO CARRERA (universidad_id, rama, carrera) VALUES (8,'Sociales','ADE+Marketing');

INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('XIOR',1, 2);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('Smart Residences ',1, 3);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('The Social Hub',1, 4);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('YOUNIQ',2, 2);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('Grupo Mestral',2, 3);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('UNIHABIT',2, 4);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('Flats2Enjoy',3, 2);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('SpotAHome',3, 3);
INSERT INTO PISO (nombre, ciudad_id, inquilinos) VALUES ('TuCasa',3, 4);

